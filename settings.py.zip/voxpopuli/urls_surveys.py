# Imports from Django
from django.conf.urls.defaults import *

#urlpatterns = patterns('brubeck.voxpopuli.views',
#    (r'^(?P<slug>[-\w]+)/results/$', 'survey_results'),
#    url(r'^(?P<slug>[-\w]+)/$', 'survey_detail', name='polls-survey-detail'),
#)

#from brubeck.voxpopuli.models import Survey
#urlpatterns += patterns('django.views.generic.list_detail',
#    (r'^p(?P<page>\d+)/$', 'object_list', {'queryset': Survey.objects.all(), 'paginate_by':10}),
#    (r'^$', 'object_list', {'queryset': Survey.objects.all(), 'paginate_by':10}),
#)
